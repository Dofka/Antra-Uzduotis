# Antra-Uzduotis

## v0.1

![Versijos v0.1 pavyzdys](2uzd.png)

Ši programa įvedus mokinių skaičių paprašo ar norėsi skaičiuoti pagal medianą ar pagal namų darbus. Tada paprašo vardo ir pavardės. Po to vartotojas pasirenka ar nori random rezultatų ar paties įvestų. Tada pagal pasirinkimą arba veda rezultatus: egzamino ir namų darbų. 

Tada Galutini balą apskaičiuoja pagal formulę: Galutinis balas = 0.4 * Vidurkis/mediana + 0.6 * egzaminas

Programa sukurta buvo naudojant vienoje versijoje masyvus kitoje vektorius

Ši programa atsižvelgia ar vartotojas teisingai įveda skaičius ar tai nėra raidės ir pnš. Žiūri, kad skaičiai nebūtų po kablelio, neperžengtų ribų. 
